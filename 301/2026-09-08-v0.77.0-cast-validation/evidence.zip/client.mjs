import fs from 'node:fs';
export const root='/tmp/phase-issue-301-validation/';
export class Client {
  constructor(code,player){this.code=code;this.player=player;this.queue=[];this.latest=null;this.lastActed=null;}
  async connect(){
    this.ws=new WebSocket('ws://127.0.0.1:19431/ws');
    this.ws.addEventListener('message',e=>{const m=JSON.parse(e.data);this.queue.push(m);if(['ServerHello','ActionRejected','ActionFailed'].includes(m.type))fs.appendFileSync(root+'replay-wire.jsonl',JSON.stringify({game:this.code,player:this.player,direction:'received',message:m})+'\n');if(m.data?.state&&['GameStarted','StateUpdate'].includes(m.type))this.latest=m.data;this.wake?.();});
    await new Promise((ok,no)=>{this.ws.addEventListener('open',ok,{once:true});this.ws.addEventListener('error',no,{once:true});});
    const hello=(await this.next(m=>m.type==='ServerHello')).data;this.hello=hello;
    this.send('ClientHello',{client_version:hello.server_version,build_commit:hello.build_commit,protocol_version:hello.protocol_version,wire_formats:[]});
    this.send('Reconnect',{game_code:this.code,player_token:'validation-player-'+this.player,full_key:{game_code:this.code,generation:1}});
    await this.next(m=>m.type==='GameStarted');return this;
  }
  send(type,data){const message=data===undefined?{type}:{type,data};if(['Action','Interaction'].includes(type))fs.appendFileSync(root+'replay-wire.jsonl',JSON.stringify({game:this.code,player:this.player,direction:'sent',message})+'\n');this.ws.send(JSON.stringify(message));}
  async next(pred,timeout=10000){
    const end=Date.now()+timeout;
    while(true){
      const err=this.queue.find(m=>['Error','ActionFailed','ActionRejected','AuthoritativeStateExportFailed'].includes(m.type));if(err)throw Error(JSON.stringify(err));
      const i=this.queue.findIndex(pred);if(i>=0)return this.queue.splice(i,1)[0];
      if(Date.now()>=end)throw Error('Timeout '+JSON.stringify(this.queue.map(m=>m.type)));
      await new Promise(resolve=>{const timer=setTimeout(()=>{this.wake=null;resolve();},Math.min(100,end-Date.now()));this.wake=()=>{clearTimeout(timer);this.wake=null;resolve();};});
    }
  }
  async act(action){
    const rev=this.latest.state_revision;
    if(rev===this.lastActed)throw Error('Duplicate action on revision '+rev);
    this.lastActed=rev;console.log(this.code,'P'+this.player,'rev',rev,'action',JSON.stringify(action));
    this.send('Action',{action});
    return (await this.next(m=>m.type==='StateUpdate'&&m.data.state_revision>rev)).data;
  }
  async interact(submission){
    const rev=this.latest.state_revision;
    if(rev===this.lastActed)throw Error('Duplicate action on revision '+rev);
    if(!this.latest.viewer_interaction.canSubmit)throw Error('Interaction not authorized');
    this.lastActed=rev;console.log(this.code,'P'+this.player,'rev',rev,'interaction',JSON.stringify(submission));
    this.send('Interaction',{submission});
    return (await this.next(m=>m.type==='StateUpdate'&&m.data.state_revision>rev)).data;
  }
  async export(label){this.send('ExportAuthoritativeState');const m=await this.next(m=>m.type==='AuthoritativeStateExport');const envelope=JSON.parse(m.data.state);fs.writeFileSync(root+label+'.json',JSON.stringify(envelope,null,2));return envelope.state;}
  close(){this.ws.close();}
}
export function summary(c){return {revision:c.latest.state_revision,waiting:c.latest.state.waiting_for,actions:c.latest.legal_actions,life:c.latest.state.players.map(p=>p.life),stack:c.latest.state.stack,exile:c.latest.state.exile};}
