import {Client,root} from './client.mjs';
import fs from 'node:fs';
import assert from 'node:assert/strict';
const code=process.argv[2]??'CWPRE1';
const ai=code==='CWAI01';
const p0=await new Client(code,0).connect();const p1=ai?null:await new Client(code,1).connect();
try{
 for(let step=0;step<8&&p0.latest.state.waiting_for.type==='Priority';step++){
  const actor=p0.latest.state.waiting_for.data.player===0?p0:p1;assert(actor);
  const rev=p0.latest.state_revision;if(actor.latest.state_revision<rev)await actor.next(m=>m.type==='StateUpdate'&&m.data.state_revision>=rev);
  const pass=actor.latest.legal_actions.find(a=>a.type==='PassPriority');assert(pass);await actor.act(pass);
  if(p0.latest.state_revision<actor.latest.state_revision)await p0.next(m=>m.type==='StateUpdate'&&m.data.state_revision>=actor.latest.state_revision);
 }
 assert.equal(p0.latest.state.waiting_for.type,'OptionalEffectChoice');
 const offered=await p0.export('301-'+code+'-cast-offered');
 assert.equal(offered.players[1].library.length,40);assert.deepEqual(offered.exile,[103,120]);
 const accept=p0.latest.legal_actions.find(a=>a.type==='DecideOptionalEffect'&&a.data.accept);assert(accept);await p0.act(accept);
 const before=await p0.export('301-'+code+'-before-target');
 assert.equal(before.waiting_for.type,'TargetSelection');
 assert.equal(before.waiting_for.data.player,0);
 assert(before.waiting_for.data.target_slots[0].legal_targets.some(t=>t.Player===1));
 const view=p0.latest.viewer_interaction;assert(view.canSubmit);
 const op=view.opportunities.find(o=>o.response.type==='schema'&&o.response.data.spec.type==='sequence');assert(op);
 const candidate=op.response.data.candidates.find(c=>c.status.type==='available'&&c.surfaces.some(s=>s.type==='player'&&s.data.seat===1));assert(candidate);
 const submission={interactionId:op.interactionId,response:{type:'sequence',data:{choiceIds:[candidate.id]}}};
 fs.writeFileSync(root+'301-'+code+'-target-offer.json',JSON.stringify({server:p0.hello,state_revision:p0.latest.state_revision,viewer_interaction:view,submission},null,2));
 let rejection=null;
 try{await p0.interact(submission);}catch(e){rejection=JSON.parse(e.message);p0.queue=p0.queue.filter(m=>m.type!=='ActionRejected');}
 const after=await p0.export('301-'+code+'-after-target');
 fs.writeFileSync(root+'301-'+code+'-result.json',JSON.stringify({server:p0.hello,rejection,waiting_for:after.waiting_for,life:after.players.map(p=>p.life),library:after.players[1].library.length,exile:after.exile,stack:after.stack,spells_cast_this_turn:after.spells_cast_this_turn},null,2));
 console.log('RESULT',code,JSON.stringify({rejection,waiting:after.waiting_for.type,life:after.players.map(p=>p.life),library:after.players[1].library.length,exile:after.exile,stack:after.stack,spells_cast_this_turn:after.spells_cast_this_turn}));
}finally{p0.close();p1?.close();}
