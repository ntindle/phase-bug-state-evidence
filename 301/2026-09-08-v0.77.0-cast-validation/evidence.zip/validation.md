# Issue #301 comment validation

Verdict: **reproduced on v0.77.0**. The comment's exile-to-prompt observations are accurate, but its **fixed** conclusion is incorrect.

Original comment: https://github.com/phase-rs/phase/issues/301#issuecomment-5592876513

## Verified runtime

- Official GitHub release: v0.77.0, latest engine release at validation time (2026-09-08).
- Server handshake: version 0.77.0, build 61715b5, protocol 67.
- Binary SHA-256: a52293b754605baa63e4d987a5208902ec394868d49c4bfd86b3fd57f3267c6a; matches GitHub asset digest.
- Binary detached Ed25519 signature and trusted comment verified against the repository-pinned public key.
- card-data.json SHA-256: 698350d9b6323011a5b86a74a4d2ea54d13b4ed26a520579be7d044f0a3692e5.
- draft-pools.json SHA-256: 56e030fdc74b2385759310de8564a58b8716035b2dccc0da709f37250cc2d3c7.
- Server bound only to 127.0.0.1:19431, using a temporary SQLite database.

## Reproduction

Imported the comment's unchanged authoritative pre-activation envelope through the release's persisted-session restore path, with two human-controlled seats. Activated Chaos Wand (source 5, ability 0), then passed priority for P0 and P1. The ability exiled Island (103) and Lightning Bolt (120), reducing P1's library from 42 to 40 and offering the optional cast.

Accepted the optional cast. The server entered TargetSelection and advertised both players as legal Bolt targets. Before target submission, however, cleanup had already returned **both Island and Bolt** to P1's library (42 cards). Object 120 had zone Library and was in the library collection, while a Spell stack entry still referenced object 120. There were no resolution frames remaining.

Submitted the exact engine-issued interaction ID and candidate ID for P1, as a sequence response. The server rejected it with action_not_allowed / unavailable / "That action is not allowed right now." State remained in TargetSelection, life totals stayed 20/20, and spells_cast_this_turn stayed zero.

Repeated acceptance and the advertised target submission with seat 1 configured as native Medium AI: same failure. This covers the native AI opponent configuration; browser UI was not exercised.

Declining the cast from the published post-state completed normally: both cards returned to the bottom, P1's library was 42, exile and stack were empty, and no spell was cast. This single decline trial checks membership/position, not statistical randomness.

## Evidence files

- 301-chaos-wand-pre.json / 301-chaos-wand-post.json: original published snapshots.
- 301-pre-restored.json: independently restored pre-activation export.
- 301-CWPRE1-cast-offered.json: independent replay reaches the original comment's stopping point.
- 301-CWPRE1-before-target.json: failure state immediately after accepting the cast.
- 301-CWPRE1-target-offer.json: server identity, advertised legal interaction and exact submitted response.
- 301-CWPRE1-after-target.json: authoritative state after rejection.
- 301-CWPRE1-result.json: compact result and rejection.
- 301-CWAI01-before-target.json / 301-CWAI01-after-target.json / 301-CWAI01-result.json: AI-seat replay.
- 301-declined-resolved.json: successful decline branch.
- replay-wire.jsonl: relevant handshake, action, interaction, and rejection messages.
- client.mjs / reproduce-301.mjs: local replay client and acceptance scenario.

## Suggested correction

Reproduced on v0.77.0 (61715b5, protocol 67). Exiling reaches the optional cast prompt correctly, but accepting the cast returns both exiled cards to the library while Lightning Bolt is still awaiting targets. The server then rejects its own advertised legal target response with action_not_allowed. Reproduced from the pre-activation snapshot and with an AI opponent. The earlier fixed verdict should be withdrawn; the original test stopped before this failure.

No engine fixes or external GitHub changes were made during this validation.
